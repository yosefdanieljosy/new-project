// Enhanced Authentication Module
const Auth = {
    // User database
    users: [
        { username: 'admin', password: 'admin123' },
        { username: 'user1', password: 'password1' }
    ],

    // Login with enhanced validation
    login: function(username, password) {
        if (!username || !password) {
            console.error('Username and password are required');
            return false;
        }

        const user = this.users.find(u => 
            u.username === username.trim() && 
            u.password === password
        );

        if (user) {
            try {
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('username', user.username);
                return true;
            } catch (e) {
                console.error('LocalStorage error:', e);
                return false;
            }
        }
        
        return false;
    },

    // Secure logout
    logout: function() {
        try {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            return true;
        } catch (e) {
            console.error('Logout failed:', e);
            return false;
        }
    },

    // Check auth status
    isAuthenticated: function() {
        return localStorage.getItem('isLoggedIn') === 'true';
    },

    // Get current user
    getCurrentUser: function() {
        return localStorage.getItem('username');
    }
};

// Optional: Session timeout (in milliseconds)
const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes

// Initialize session timer
let sessionTimer;

function resetSessionTimer() {
    clearTimeout(sessionTimer);
    sessionTimer = setTimeout(() => {
        Auth.logout();
        window.location.href = 'index.html';
    }, SESSION_TIMEOUT);
}

// Initialize auth check on page load
document.addEventListener('DOMContentLoaded', function() {
    if (Auth.isAuthenticated()) {
        resetSessionTimer();
        // Track user activity
        document.addEventListener('mousemove', resetSessionTimer);
        document.addEventListener('keypress', resetSessionTimer);
    }
});