document.addEventListener('DOMContentLoaded', function() {
    // 1. Authentication Check
    if (!localStorage.getItem('isLoggedIn')) {
        window.location.href = 'index.html';
        return;
    }

    // 2. Get User Data
    const username = localStorage.getItem('username');
    if (!username) {
        console.error('No username found');
        window.location.href = 'index.html';
        return;
    }

    // 3. Update UI
    document.getElementById('welcome-message').textContent = `Welcome, ${username}!`;
    document.getElementById('profile-username').textContent = username;
    document.getElementById('profile-email').textContent = `${username}@example.com`;
    document.getElementById('join-date').textContent = new Date().toLocaleDateString();

    // 4. Logout Handler
    document.getElementById('logout-btn').addEventListener('click', function() {
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('username');
        window.location.href = 'index.html';
    });

    console.log('Profile loaded successfully');
});